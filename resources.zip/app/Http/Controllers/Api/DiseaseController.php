<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Disease;
use App\Inference\InferenceEngine;
use PDF;

class DiseaseController extends Controller
{
    public function getDiseases()
    {
        $diseases = Disease::all();
        return response()->json($diseases);
    }

    public function getDiseaseSymptoms()
    {
        $diseases = Disease::with("symptoms")->get();
        $disease_symptoms = [];

        foreach ($diseases as $disease) {
            $symptoms = [];

            if ($disease->symptoms !== null) {
                foreach ($disease->symptoms as $disease_symptom) {
                    $symptoms[$disease_symptom->id] = [
                        "weight" => $disease_symptom->pivot->weight,
                    ];
                }
            }

            $disease_symptoms[$disease->id] = $symptoms;
        }

        return $disease_symptoms;
    }

    public function getDiagnose(Request $request)
    {
        $data = $request->json()->all();
        $patient = $data["data"]["patient"];
        $symptoms = $data["data"]["symptoms"];
        $inferenceEngine = new InferenceEngine();
        $diseaseSymptoms = $this->getDiseaseSymptoms();
        $result = $inferenceEngine->forwardChaining($diseaseSymptoms, $symptoms);

        return response()->json([
            "result" => $result,
        ]);
    }

    public function downloadReport()
    {
        $pdf = PDF::loadView('diagnose-report');
        return $pdf->download('pdf_file.pdf');
    }
}